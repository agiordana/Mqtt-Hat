#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/foreach.hpp>
#include <iostream>
#include <sstream>

using namespace std;

int main() {
  string tmp;
  stringstream jm;
  jm<< "{ \"name\":\"Bath\", \"type\":\"cyclic\", \"input\":[\"test/mqtthat/gpio/IN1\",\"test/mqtthat/gpio/IN2\"], \"output\":[{\"name\":\"test/mqtthat/gpio/OUT0\", \"alias\":\"bath\"},{\"name\":\"test/mqtthat/gpio/OUT1\", \"alias\":\"mirror\"}] }";
  boost::property_tree::ptree pt, input, output;
  read_json(jm,pt);
  cout<<pt.get<string>("name")<<endl;
  cout<<pt.get<string>("type")<<endl;
  input = pt.get_child("input");
  output = pt.get_child("output");
  BOOST_FOREACH(boost::property_tree::ptree::value_type &v, output) {
	  cout<<v.second.get<string>("name")<<endl;
	  cout<<v.second.get<string>("alias")<<endl;
  }
  BOOST_FOREACH(boost::property_tree::ptree::value_type &v, input) {
	  assert(v.first.empty());
	  tmp = v.second.data();
	  cout<<tmp<<endl;
  }
  return 0;
}
