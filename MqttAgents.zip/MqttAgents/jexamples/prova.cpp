#include "json.hpp"
#include <cstddef>
#include <iostream>

using json::JSON;
using namespace std;

int main() {
  string jm = "{ \"name\":\"Bath\", \"type\":\"cyclic\", \"input\":[\"test/mqtthat/gpio/IN1\",\"test/mqtthat/gpio/IN2\"], \"output\":[{\"name\":\"test/mqtthat/gpio/OUT0\", \"alias\":\"bath\"},{\"name\":\"test/mqtthat/gpio/OUT1\", \"alias\":\"mirror\"}] }";
  JSON obj = JSON::Load(jm);
  cout<<obj<<endl;
  cout<<obj["name"]<<endl;
  cout<<obj["type"]<<endl;
  JSON output = obj["output"];
  JSON input = obj["input"];
  cout<<output<<endl;
  for( auto &j : output.ArrayRange() ) {
     std::cout << j["alias"] << "\n";
     std::cout << j["name"] << "\n";
  }
  for( auto &j : input.ArrayRange() ) cout<<j<<endl;
  return 0;
}
