#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

int main(int argc, char **argv) {
	map<pair<string, string>, string> pmap;
	
	pmap[make_pair("AA","BB")] = "UUUUU";
	pmap[make_pair("AA","CC")] = "ZZZZZZ";
	pmap[make_pair("DD", "KK")] = "YYYYYY";

	for(auto it=pmap.begin(); it!=pmap.end(); it++) cout<<it->second<<endl;
	cout<<pmap[make_pair("AA","CC")];
	pair<string,string> key;
	key = make_pair("DD","KK");
	cout<<pmap[key]<<endl;
	return 0;
}
