#include "prova.h"

Task::Task() {
   a=3;
   b=12;
}

void Task::tr1() {
   cout <<"original: "<<a+b <<endl;
}

void Task::start() {
   tt1 = thread(&Task::tr1,this);
}

Derived::Derived() {
   c.push_back(123);
}

void Derived::tr1() {
   cout<<"Derived: "<<a+b+c[0]<<endl;
   print(c);
}

bool Derived::print(vector<int>& v) {
	v.push_back(3);
	cout<<"Print: "<<v[0]<<" "<<v.size()<<endl;
	return true;
}
