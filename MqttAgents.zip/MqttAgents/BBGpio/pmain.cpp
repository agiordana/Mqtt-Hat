#include "prova.h"

int main() {
	Task* tt = new Derived;
	tt->start();
	tt->tt1.join();
}
