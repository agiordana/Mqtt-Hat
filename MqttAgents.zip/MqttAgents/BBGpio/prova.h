#include <thread>
#include <vector>
#include <iostream>

using namespace std;


class Task {
public:
	int a;
	int b;
	Task();
	thread tt1;
	virtual void tr1();
	void start();
};

class Derived: public Task {
public:

	vector<int> c;

	Derived();

	void tr1() override;
	bool print(vector<int>&);
};
